// Configuration
const ANTHROPIC_API_KEY = "YOUR_CLAUDE_API_KEY"; // Placeholder

// Global State
let currentLang = 'en'; // default language
const API_URL = "https://api.anthropic.com/v1/messages";

// State
let queue = [];
let queueIdCounter = 4; // Start from 4 since we preload 3 demos
let currentFilter = 'all';

// DOM Elements
const navBtns = document.querySelectorAll('.nav-btn, .nav-link');
const views = document.querySelectorAll('.view-section');
const registrationForm = document.getElementById('registration-form');
const submitBtn = document.getElementById('submit-btn');
// Removed: const btnText = submitBtn.querySelector('.btn-text');
// Removed: const spinner = submitBtn.querySelector('.spinner');

// Lightbox
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightbox-img');
const lightboxClose = document.querySelector('.lightbox-close');

// Queue DOM
const queueTbody = document.getElementById('queue-tbody');
const emptyQueueMsg = document.getElementById('empty-queue-msg');
const btnText = document.querySelector('.btn-text');
const spinner = document.querySelector('.spinner');

const locationBtn = document.getElementById('btn-location');
const langSwitch = document.getElementById('lang-switch');

const filterChips = document.querySelectorAll('.filter-chip');
const callNextBtn = document.getElementById('call-next-btn');

// Initialization
document.addEventListener('DOMContentLoaded', () => {
    // Check if there is a saved language preference
    const savedLang = localStorage.getItem('hospital_lang');
    if (savedLang) {
        currentLang = savedLang;
        langSwitch.value = currentLang;
    }
    updateLanguage();

    // Request notification permission early
    if ("Notification" in window) {
        Notification.requestPermission();
    }

    setupDragAndDrop();
    loadDemoData();
    initCarousel();
});

// --- Carousel Logic ---
function initCarousel() {
    const slides = document.querySelectorAll('.banner-slide');
    const dots = document.querySelectorAll('#carousel-dots .dot');
    if (!slides.length) return;

    let currentSlide = 0;
    setInterval(() => {
        slides[currentSlide].classList.remove('active');
        dots[currentSlide].classList.remove('active');
        
        currentSlide = (currentSlide + 1) % slides.length;
        
        slides[currentSlide].classList.add('active');
        dots[currentSlide].classList.add('active');
    }, 4000);
}

// --- i18n Logic ---
function updateLanguage() {
    document.documentElement.lang = currentLang;
    
    // Find all elements with a data-i18n attribute
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (translations[currentLang] && translations[currentLang][key]) {
            el.innerHTML = translations[currentLang][key];
        }
    });

    // Update form field placeholders manually
    const nameInput = document.getElementById('patient-name');
    const ageInput = document.getElementById('patient-age');
    const phoneInput = document.getElementById('patient-phone');
    const locationInput = document.getElementById('patient-location');
    const symptomsInput = document.getElementById('patient-symptoms');
    
    // Default placeholders
    let placeholders = {
        name: "Jane Doe",
        age: "45",
        phone: "(555) 123-4567",
        location: "123 Main St",
        symptoms: "Describe what the patient is experiencing..."
    };

    if (currentLang === 'hi') {
        placeholders = { name: "जेन डो", age: "45", phone: "(555) 123-4567", location: "123 मुख्य सड़क", symptoms: "मरीज क्या अनुभव कर रहा है इसका वर्णन करें..." };
    } else if (currentLang === 'te') {
        placeholders = { name: "జానే దో", age: "45", phone: "(555) 123-4567", location: "123 ప్రధాన వీధి", symptoms: "రోగి ఏమి అనుభవిస్తున్నారో వివరించండి..." };
    } else if (currentLang === 'ta') {
        placeholders = { name: "ஜேன் டோ", age: "45", phone: "(555) 123-4567", location: "123 முதன்மை சாலை", symptoms: "நோயாளி என்ன அனுபவிக்கிறார் என்பதை விவரிக்கவும்..." };
    }

    if (nameInput) nameInput.placeholder = placeholders.name;
    if (ageInput) ageInput.placeholder = placeholders.age;
    if (phoneInput) phoneInput.placeholder = placeholders.phone;
    if (locationInput) locationInput.placeholder = placeholders.location;
    if (symptomsInput) symptomsInput.placeholder = placeholders.symptoms;
}

langSwitch.addEventListener('change', (e) => {
    currentLang = e.target.value;
    localStorage.setItem('hospital_lang', currentLang);
    updateLanguage();
});

// --- Location Logic ---
locationBtn.addEventListener('click', async () => {
    const locInput = document.getElementById('patient-location');
    
    if (!navigator.geolocation) {
        showToast('Error', 'Geolocation is not supported by your browser.', 'error');
        return;
    }

    // Temporarily disable the button to prevent multiple clicks
    locationBtn.disabled = true;
    locationBtn.style.opacity = '0.5';
    showToast('Info', 'Fetching your location...', 'info');

    navigator.geolocation.getCurrentPosition(
        async (position) => {
            const { latitude, longitude } = position.coords;
            try {
                // OpenStreetMaps Nominatim Reverse Geocoding via JSON endpoint
                const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`;
                const response = await fetch(url, { headers: { 'Accept-Language': currentLang } });
                if (!response.ok) throw new Error('Failed to fetch address');
                
                const data = await response.json();
                if (data && data.display_name) {
                    locInput.value = data.display_name;
                    showToast('Success', 'Location updated successfully.', 'success');
                } else {
                     showToast('Warning', 'Could not resolve exact address.', 'warning');
                     locInput.value = `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
                }
            } catch (error) {
                console.error("Geocoding Error:", error);
                locInput.value = `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
                showToast('Warning', 'Failed to fetch street address. Using raw coordinates instead.', 'warning');
            } finally {
                locationBtn.disabled = false;
                locationBtn.style.opacity = '1';
            }
        },
        (error) => {
            console.error("Geolocation Setup Error", error);
            showToast('Error', 'Could not fetch location. Please ensure location permissions are granted.', 'error');
            locationBtn.disabled = false;
            locationBtn.style.opacity = '1';
        },
        { timeout: 10000 }
    );
});

// --- SOS System Logic ---
const sosBtn = document.getElementById('sos-btn');

sosBtn.addEventListener('click', () => {
    const confirmMsg = (translations[currentLang] && translations[currentLang]['sos.confirm']) ? 
        translations[currentLang]['sos.confirm'] : 
        "Trigger SOS Accident Response? An ambulance will be dispatched to your location.";
        
    if (!confirm(confirmMsg)) return;

    if (!navigator.geolocation) {
        showToast('Error', 'Geolocation is not supported by your browser for SOS.', 'error');
        return;
    }

    showToast('SOS Initiated', 'Locating accident for ambulance dispatch...', 'warning');
    
    // Temporarily pulse button faster
    sosBtn.style.animationDuration = '0.5s';

    navigator.geolocation.getCurrentPosition(
        async (position) => {
            const { latitude, longitude } = position.coords;
            let finalLocation = `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;

            try {
                const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`;
                const response = await fetch(url, { headers: { 'Accept-Language': currentLang } });
                if (response.ok) {
                    const data = await response.json();
                    if (data && data.display_name) {
                        finalLocation = data.display_name;
                    }
                }
            } catch (error) {
                console.error("SOS Geocoding Error:", error);
            }

            // Create SOS patient
            const sosPatient = {
                id: queueIdCounter++,
                name: "UNKNOWN (SOS)",
                age: 0,
                phone: "URGENT",
                location: finalLocation,
                symptoms: "URGENT SOS ACCIDENT - AMBULANCE DISPATCHED",
                urgency: "emergency",
                confidence: 100,
                reasoning: "Accident reported via SOS button. Immediate response required.",
                transport: "Ambulance Dispatched",
                evidence: null,
                arrivalTime: Date.now()
            };

            // Force it to the absolute top of the queue and re-render
            queue.unshift(sosPatient);
            applySorting();
            renderQueue();
            updateStats();
            
            showToast('SOS Dispatched', `Ambulance deployed to ${finalLocation}`, 'success');
            fireDesktopNotification("SOS Accident Alert", `Ambulance dispatched to ${finalLocation}`);

            // TTS Alert
            const speechText = `Emergency SOS accident reported at ${finalLocation}. Ambulance dispatched.`;
            const utterance = new SpeechSynthesisUtterance(speechText);
            utterance.rate = 1.0;
            utterance.pitch = 1.2;
            window.speechSynthesis.speak(utterance);

            // Reset button animation
            sosBtn.style.animationDuration = '2s';

            // Switch to Dashboard View to see it
            document.querySelector('.nav-link[data-target="queue-view"]').click();
        },
        (error) => {
            console.error("SOS Geolocation Error", error);
            showToast('SOS Locating Failed', 'Could not get precise location, but SOS was still dispatched!', 'error');
            
            // Still dispatch SOS even if location fails
            const sosPatient = {
                id: queueIdCounter++,
                name: "UNKNOWN (SOS)",
                age: 0,
                phone: "URGENT",
                location: "UNKNOWN LOCATION (GEOLOCATION FAILED)",
                symptoms: "URGENT SOS ACCIDENT - AMBULANCE DISPATCHED",
                urgency: "emergency",
                confidence: 100,
                reasoning: "Accident reported via SOS button. Immediate response required.",
                transport: "Ambulance Dispatched",
                evidence: null,
                arrivalTime: Date.now()
            };

            queue.unshift(sosPatient);
            applySorting();
            renderQueue();
            updateStats();

            fireDesktopNotification("SOS Accident Alert", "Ambulance dispatched to UNKNOWN LOCATION.");
            const speechText = "Emergency SOS accident reported. Location unknown. Assistance required immediately.";
            const utterance = new SpeechSynthesisUtterance(speechText);
            utterance.rate = 1.0;
            utterance.pitch = 1.2;
            window.speechSynthesis.speak(utterance);

            sosBtn.style.animationDuration = '2s';
            document.querySelector('.nav-link[data-target="queue-view"]').click();
        },
        { timeout: 10000, enableHighAccuracy: true }
    );
});

// --- Navigation
// Event Listeners
navBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        // Handle active state for buttons
        navBtns.forEach(b => {
            if(b.classList.contains('nav-btn')) b.classList.remove('active');
            if(b.classList.contains('nav-link')) b.classList.remove('active');
        });
        
        btn.classList.add('active');

        // Handle views
        const targetView = btn.dataset.target;
        views.forEach(view => {
            if (view.id === targetView) {
                view.classList.add('active');
                if (targetView === 'queue-view') {
                    renderQueue();
                }
            } else {
                view.classList.remove('active');
            }
        });
    });
});

// --- File Upload & Drag-Drop ---
let uploadedPhoto = null; // Store base64 or object URL
let uploadedReport = null;

function setupDragAndDrop() {
    setupZone('photo-upload-zone', 'photo-upload', handlePhotoUpload);
    setupZone('report-upload-zone', 'report-upload', handleReportUpload);

    // Remove file buttons
    document.querySelectorAll('.remove-file-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            const targetId = btn.getAttribute('data-target');
            document.getElementById(targetId).value = "";
            if (targetId === 'photo-upload') {
                uploadedPhoto = null;
                document.getElementById('photo-preview-container').style.display = 'none';
            } else {
                uploadedReport = null;
                document.getElementById('report-preview-container').style.display = 'none';
            }
        });
    });
}

function setupZone(zoneId, inputId, handleFile) {
    const zone = document.getElementById(zoneId);
    const input = document.getElementById(inputId);

    // Click triggers label behavior for input type file automatically, but for DND:
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        zone.addEventListener(eventName, preventDefaults, false);
    });

    ['dragenter', 'dragover'].forEach(eventName => {
        zone.addEventListener(eventName, () => zone.classList.add('dragover'), false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        zone.addEventListener(eventName, () => zone.classList.remove('dragover'), false);
    });

    zone.addEventListener('drop', (e) => {
        const dt = e.dataTransfer;
        const files = dt.files;
        if (files && files.length > 0) {
            handleFile(files[0]);
        }
    });

    input.addEventListener('change', (e) => {
        if (e.target.files && e.target.files.length > 0) {
            handleFile(e.target.files[0]);
        }
    });
}

function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
}

function handlePhotoUpload(file) {
    if (!file.type.startsWith('image/')) {
        showToast('Info', 'Please upload a valid image file.', 'info');
        return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
        uploadedPhoto = e.target.result; // base64 string
        document.getElementById('photo-preview').src = uploadedPhoto;
        document.getElementById('photo-preview-container').style.display = 'flex';
    };
    reader.readAsDataURL(file);
}

function handleReportUpload(file) {
    // Simplified for UI demo
    uploadedReport = file;
    document.getElementById('report-filename').textContent = file.name;
    document.getElementById('report-preview-container').style.display = 'flex';
}

// --- App State & Queue Logic ---

function loadDemoData() {
    queue = [
        {
            id: 1,
            name: "Arjun Mehta",
            age: 52,
            phone: "+1 555-0100",
            location: "North Wing",
            symptoms: "Severe crushing chest pain radiating to left arm, sweating, shortness of breath.",
            urgency: "emergency",
            confidence: 94,
            reasoning: "Classic presentation of acute myocardial infarction (heart attack). Requires immediate intervention.",
            transport: "Ambulance",
            evidence: null,
            arrivalTime: Date.now() - 1000000 // In the past
        },
        {
            id: 2,
            name: "Rekha Verma",
            age: 28,
            phone: "+1 555-0101",
            location: "Downtown",
            symptoms: "High fever (103F), stiff neck, incredible headache, sensitivity to light for past 6 hours.",
            urgency: "high",
            confidence: 81,
            reasoning: "Symptoms are highly suspicious for meningitis. Prompt empirical treatment and lumbar puncture needed.",
            transport: "Taxi / Ride Share",
            evidence: null,
            arrivalTime: Date.now() - 500000
        },
        {
            id: 3,
            name: "Dinesh Kumar",
            age: 41,
            phone: "+1 555-0102",
            location: "Suburbia",
            symptoms: "Mild lower abdominal discomfort, slightly nauseous. No fever. Pain is intermittent and dull.",
            urgency: "manual", // Mapped to low and flagged for manual
            confidence: 45,
            reasoning: "Symptoms are vague. Could be mild gastroenteritis or early appendicitis. Confidence is low due to non-specific presentation.",
            transport: "Drive / Public Transit",
            evidence: null,
            arrivalTime: Date.now() - 200000
        }
    ];

    applySorting();
    renderQueue();
    updateStats();
}

const URGENY_MAP = {
    'emergency': 4,
    'high': 3,
    'medium': 2,
    'low': 1,
    'manual': 0
};

function getUrgencyRank(urgency) {
    switch (urgency) {
        case 'emergency': return 4;
        case 'high': return 3;
        case 'medium': return 2;
        case 'low': return 1;
        case 'manual': return 0;
        default: return 0;
    }
}

function applySorting() {
    queue.sort((a, b) => {
        // Tie-break 1: Urgency Rank
        const rankA = getUrgencyRank(a.urgency);
        const rankB = getUrgencyRank(b.urgency);
        
        if (rankA !== rankB) return rankB - rankA; // Descending
        
        // Tie-break 2: Confidence
        if (a.confidence !== b.confidence) return b.confidence - a.confidence; // Descending

        // Tie-break 3: Arrival time
        return a.arrivalTime - b.arrivalTime; // Ascending (FIFO)
    });

    // Reassign positions mentally when rendering.
}

// --- UI Rendering ---

function updateStats() {
    document.getElementById('stat-total').textContent = queue.length;
    document.getElementById('nav-queue-count').textContent = queue.length;

    let emergency = 0, high = 0, manual = 0;
    queue.forEach(p => {
        if (p.urgency === 'emergency') emergency++;
        if (p.urgency === 'high') high++;
        if (p.urgency === 'manual') manual++;
    });

    document.getElementById('stat-emergency').textContent = emergency;
    document.getElementById('stat-high').textContent = high;
    document.getElementById('stat-manual').textContent = manual;
}

// Setup Filters
filterChips.forEach(chip => {
    chip.addEventListener('click', () => {
        filterChips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        currentFilter = chip.getAttribute('data-filter');
        renderQueue();
    });
});

function renderQueue() {
    queueTbody.innerHTML = '';

    const filteredQueue = queue.filter(p => currentFilter === 'all' || p.urgency === currentFilter);

    if (filteredQueue.length === 0) {
        emptyQueueMsg.style.display = 'block';
        document.querySelector('.table-container').style.display = 'none';
        return;
    } else {
        emptyQueueMsg.style.display = 'none';
        document.querySelector('.table-container').style.display = 'block';
    }

    filteredQueue.forEach((patient, index) => {
        const tr = document.createElement('tr');
        
        // Confidence Color
        let confColor = 'var(--priority-low)';
        if (patient.confidence < 60) confColor = 'var(--priority-emergency)';
        else if (patient.confidence < 80) confColor = 'var(--priority-medium)';

        // Priority Badge text
        let badgeClass = `badge-${patient.urgency}`;
        let badgeText = patient.urgency;
        if (patient.urgency === 'manual') {
            badgeText = 'Manual Review';
        }

        // Transport Icon/Class
        let transportClass = 'public';
        let transportIcon = '🚌';
        if (patient.transport) {
            const t = patient.transport.toLowerCase();
            if (t.includes('ambulance') || t.includes('emergency')) { transportClass = 'ambulance'; transportIcon = '🚑'; }
            else if (t.includes('taxi') || t.includes('ride')) { transportClass = 'taxi'; transportIcon = '🚕'; }
            else if (t.includes('walk')) { transportClass = 'public'; transportIcon = '🚶'; }
            else if (t.includes('drive') || t.includes('car')) { transportClass = 'public'; transportIcon = '🚗'; }
        }

        // Mapping link
        const mapUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(patient.location)}`;
        const trackTooltip = (translations[currentLang] && translations[currentLang]['track.btn']) ? translations[currentLang]['track.btn'] : "Track";

        tr.innerHTML = `
            <td class="queue-pos">${index + 1}</td>
            <td>
                <div class="patient-info">
                    <span class="patient-name">${htmlEscape(patient.name)}</span>
                    <span class="patient-meta">${patient.age} yrs • ${htmlEscape(patient.phone)}</span>
                    <span class="symptom-preview" title="${htmlEscape(patient.symptoms)}">${htmlEscape(patient.symptoms)}</span>
                </div>
            </td>
            <td>
                <div style="display: flex; flex-direction: column; align-items: flex-start;">
                    <span style="font-size: 0.9rem; color: var(--text-muted);">${htmlEscape(patient.location)}</span>
                    ${patient.transport ? `<span class="transport-badge ${transportClass}">${transportIcon} ${htmlEscape(patient.transport)}</span>` : ''}
                </div>
            </td>
            <td>
                <span class="priority-badge ${badgeClass}">${badgeText}</span>
                <div class="reasoning-text">${htmlEscape(patient.reasoning)}</div>
            </td>
            <td>
                <div class="confidence-module">
                    <div class="conf-text" style="color: ${confColor}">${patient.confidence}%</div>
                    <div class="conf-bar-bg">
                        <div class="conf-bar-fill" style="width: ${patient.confidence}%; background-color: ${confColor}"></div>
                    </div>
                </div>
            </td>
            <td>
                ${patient.evidence 
                    ? `<img src="${patient.evidence}" alt="Evidence" class="evidence-thumb" onclick="openLightbox('${patient.evidence}')">` 
                    : '<span class="text-muted" style="font-size: 0.8rem;">None</span>'}
            </td>
            <td>
                <div style="display: flex; gap: 8px;">
                    <a href="${mapUrl}" target="_blank" class="btn-icon" title="Directions">📍</a>
                    ${transportClass === 'ambulance' ? `<button class="btn-icon track-btn" onclick="openTrackingModal(${patient.id})" title="${trackTooltip}">📡</button>` : ''}
                </div>
            </td>
        `;

        queueTbody.appendChild(tr);
    });
}

// --- Auto Call System (TTS) ---

callNextBtn.addEventListener('click', () => {
    if (queue.length === 0) {
        showToast('Info', 'The queue is currently empty.', 'info');
        return;
    }

    // Get the first patient in the sorted queue (the one to be called)
    const patientToCall = queue[0];
    
    // Construct the speech text
    const speechText = `Calling, ${patientToCall.name}. Please proceed to the registration desk. Priority: ${patientToCall.urgency === 'manual' ? 'Manual Review' : patientToCall.urgency}.`;
    
    // Create and speak the utterance
    const utterance = new SpeechSynthesisUtterance(speechText);
    utterance.rate = 0.9; // Slightly slower for clarity
    utterance.pitch = 1.0;
    
    window.speechSynthesis.speak(utterance);
    
    // Provide a visual cue
    showToast('Calling Patient', `🔊 Now playing announcement for ${patientToCall.name}...`, 'info');
    
    // Remove the patient from the queue after calling
    utterance.onend = () => {
        queue.shift(); // Remove the first element
        applySorting();
        renderQueue();
        updateStats();
        showToast('Queue Updated', `${patientToCall.name} has been called and removed from the queue.`, 'success');
    };
});

// --- Form Submission & Claude API ---

registrationForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('patient-name').value;
    const age = document.getElementById('patient-age').value;
    const phone = document.getElementById('patient-phone').value;
    const location = document.getElementById('patient-location').value;
    const symptoms = document.getElementById('patient-symptoms').value;

    if (!name || !age || !phone || !location || !symptoms) {
        showToast('Error', 'Please fill all required fields.', 'error');
        return;
    }

    setLoading(true);

    try {
        const triageResult = await callClaudeTriage(age, symptoms, uploadedPhoto, currentLang);
        
        let finalUrgency = triageResult.urgency.toLowerCase();
        // Fallback validation
        if (!['emergency', 'high', 'medium', 'low'].includes(finalUrgency)) finalUrgency = 'low';

        if (triageResult.confidence < 60) {
            finalUrgency = 'manual';
        }

        const newPatient = {
            id: queueIdCounter++,
            name: name,
            age: parseInt(age),
            phone: phone,
            location: location,
            symptoms: symptoms,
            urgency: finalUrgency,
            confidence: triageResult.confidence,
            reasoning: triageResult.reasoning,
            transport: triageResult.transport_suggestion || "Public Transit",
            evidence: uploadedPhoto, // Assuming it's base64 data url from upload
            arrivalTime: Date.now()
        };

        queue.push(newPatient);
        applySorting();
        renderQueue();
        updateStats();

        // Check assigned position for notifications
        const currentPos = queue.findIndex(p => p.id === newPatient.id) + 1;
        
        showToast('Success', `${name} registered. Queue Position: ${currentPos}`, 'success');

        if (currentPos <= 3) {
            showToast('Warning', `Patient placed in high-priority position ${currentPos}`, 'warning');
            fireDesktopNotification("High Priority Patient Added", `${name} added at pos ${currentPos} for: ${finalUrgency.toUpperCase()}`);
        }

        // Reset form
        registrationForm.reset();
        document.getElementById('photo-upload').value = "";
        document.getElementById('report-upload').value = "";
        uploadedPhoto = null;
        uploadedReport = null;
        document.getElementById('photo-preview-container').style.display = 'none';
        document.getElementById('report-preview-container').style.display = 'none';

        // Switch to Live Queue view to see result
        document.querySelector('.nav-link[data-target="queue-view"]').click();

    } catch (err) {
        console.error("Triage Error:", err);
        showToast('API Error', 'Failed to communicate with AI triage. Please try again.', 'error');
    } finally {
        setLoading(false);
    }
});

function setLoading(isLoading) {
    if (isLoading) {
        btnText.style.display = 'none';
        spinner.style.display = 'block';
        submitBtn.disabled = true;
    } else {
        btnText.style.display = 'block';
        spinner.style.display = 'none';
        submitBtn.disabled = false;
    }
}

async function callClaudeTriage(age, symptoms, base64Photo, lang) {
    // Convert language code to full language name
    const langNames = {
        'en': 'English',
        'hi': 'Hindi',
        'te': 'Telugu',
        'ta': 'Tamil'
    };
    const targetLang = langNames[lang] || 'English';

    // If the API key is exactly YOUR_CLAUDE_API_KEY, simulate a fake response instead of failing
    if (ANTHROPIC_API_KEY === "YOUR_CLAUDE_API_KEY") {
        console.warn("Using fake API response because ANTHROPIC_API_KEY is not set.");
        return new Promise(resolve => {
            setTimeout(() => {
                resolve({
                    urgency: "high",
                    confidence: 75,
                    reasoning: "[DEMO MODE] This is a simulated response indicating a potentially serious condition needing attention.",
                    transport_suggestion: "Taxi / Drive"
                });
            }, 1500);
        });
    }

    const messages = [];
    
    // Construct content array
    const content = [];
    
    // Add image if exists
    if (base64Photo) {
        // base64Photo is like: data:image/jpeg;base64,/9j/4AAQSk...
        try {
            const matches = base64Photo.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
            if (matches && matches.length === 3) {
                content.push({
                    type: "image",
                    source: {
                        type: "base64",
                        media_type: matches[1],
                        data: matches[2]
                    }
                });
            }
        } catch(e) { console.error("Could not parse image base64 format"); }
    }

    const textPayload = `You are a medical triage AI. Analyze this patient:
Age: ${age}
Symptoms: ${symptoms}

Return ONLY a valid JSON object matching this schema exactly:
{ 
  "urgency": "emergency" | "high" | "medium" | "low", 
  "confidence": <integer between 0-100>, 
  "reasoning": "<1-2 sentence explanation written gracefully in ${targetLang}>",
  "transport_suggestion": "<Short string suggesting transport method written gracefully in ${targetLang} based on symptoms e.g., Ambulance, Taxi, Public Transit>"
}
Do not use markdown blocks like \`\`\`json. Return pure JSON string.`;

    content.push({
        type: "text",
        text: textPayload
    });

    messages.push({
        role: "user",
        content: content
    });

    const body = {
        model: "claude-3-5-sonnet-20241022",
        max_tokens: 256,
        system: "You evaluate medical symptoms to output only rigorous JSON triage information.",
        messages: messages
    };

    const response = await fetch(API_URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "anthropic-dangerous-direct-browser-access": "true"
        },
        body: JSON.stringify(body)
    });

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`API error: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    let replyText = data.content && data.content[0] ? data.content[0].text : "";
    
    // Strip markdown formatting if Claude returned it despite instructions
    replyText = replyText.replace(/```json\s*/i, '').replace(/```\s*$/i, '').trim();

    const parsed = JSON.parse(replyText);
    return parsed;
}

// --- Utilities ---

function showToast(title, message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    toast.innerHTML = `
        <div class="toast-content">
            <span class="toast-title">${title}</span>
            <span class="toast-message">${message}</span>
        </div>
    `;
    
    container.appendChild(toast);
    
    // Force reflow for transform
    void toast.offsetWidth;
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 400); // Wait for transition
    }, 5000);
}

function fireDesktopNotification(title, body) {
    if ("Notification" in window && Notification.permission === "granted") {
        new Notification(title, { body: body, icon: "favicon.ico" }); // Adding a placeholder icon option
    }
}

function htmlEscape(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

window.openLightbox = function(src) {
    lightboxImg.src = src;
    lightbox.classList.add('show');
};

lightboxClose.addEventListener('click', () => {
    lightbox.classList.remove('show');
    setTimeout(() => { lightboxImg.src = ""; }, 300);
});

lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) {
        lightboxClose.click();
    }
});

// --- Claude API Parser ---
function parseClaudeJson(text) {
    try {
        const jsonMatch = text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
            return JSON.parse(jsonMatch[0]);
        }
        return JSON.parse(text);
    } catch (e) {
        console.error("JSON Parsing failed on:", text);
        return {
            urgency: "manual",
            confidence: 0,
            reasoning: "Failed to parse API response. Manual review required.",
            transport_suggestion: "Unknown"
        };
    }
}

// --- Live Ambulance Tracking (Leaflet.js) ---
let trackingMap = null;
let ambulanceMarker = null;
let routingPolyline = null;
let animationTimer = null;

const trackingModal = document.getElementById('tracking-modal');
const trackingContainer = document.querySelector('.tracking-container');

function closeTrackingModal() {
    trackingModal.classList.remove('active');
    if (animationTimer) {
        cancelAnimationFrame(animationTimer);
        animationTimer = null;
    }
}

// Close only when clicking the X button
document.querySelector('.tracking-close').addEventListener('click', closeTrackingModal);

// Expose globally so onclick attribute in HTML table can access it
window.openTrackingModal = function(patientId) {
    try {
        const patient = queue.find(p => p.id === patientId);
        if (!patient) return;

        trackingModal.classList.add('active');

        // Default hospital coords (New Delhi - Smart Hospital HQ simulation)
        const hospitalLat = 28.6139;
        const hospitalLng = 77.2090;
        const hospitalName = 'Smart Hospital HQ - New Delhi';

        // Patient starts at random nearby location
        const patLat = hospitalLat + (Math.random() * 0.05 + 0.02) * (Math.random() > 0.5 ? 1 : -1);
        const patLng = hospitalLng + (Math.random() * 0.05 + 0.02) * (Math.random() > 0.5 ? 1 : -1);

        // Update destination label
        document.getElementById('track-hosp-val').textContent = hospitalName;

        if (!trackingMap) {
            trackingMap = L.map('tracking-map', { zoomControl: true }).setView([hospitalLat, hospitalLng], 13);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors',
                maxZoom: 18
            }).addTo(trackingMap);

            // Persistent hospital marker
            const hospIcon = L.divIcon({ html: '🏥', className: 'hospital-marker-icon', iconSize: [32, 32], iconAnchor: [16, 16] });
            L.marker([hospitalLat, hospitalLng], { icon: hospIcon })
                .addTo(trackingMap)
                .bindPopup(`<b>${hospitalName}</b><br>Emergency Bay Active`);
        }

        // Let the modal render its full size before telling Leaflet to recalculate
        setTimeout(() => {
            try {
                trackingMap.invalidateSize();

                // Clean up previous ambulance + route (not the hospital marker)
                if (ambulanceMarker) { trackingMap.removeLayer(ambulanceMarker); ambulanceMarker = null; }
                if (routingPolyline) { trackingMap.removeLayer(routingPolyline); routingPolyline = null; }
                if (animationTimer) { cancelAnimationFrame(animationTimer); animationTimer = null; }

                // Build route with zigzag to simulate city streets
                const segments = 30;
                const routePoints = [];
                for (let i = 0; i <= segments; i++) {
                    const frac = i / segments;
                    let lat = patLat + (hospitalLat - patLat) * frac;
                    let lng = patLng + (hospitalLng - patLng) * frac;
                    if (i > 0 && i < segments) {
                        lat += (Math.random() * 0.003 - 0.0015);
                        lng += (Math.random() * 0.003 - 0.0015);
                    }
                    routePoints.push([lat, lng]);
                }

                // Draw traffic-colored polyline segments
                const routeGroup = L.featureGroup().addTo(trackingMap);
                routingPolyline = routeGroup;

                let totalDist = 0;
                for (let i = 0; i < routePoints.length - 1; i++) {
                    const p1 = L.latLng(routePoints[i]);
                    const p2 = L.latLng(routePoints[i + 1]);
                    totalDist += p1.distanceTo(p2);

                    const r = Math.random();
                    const color = r > 0.82 ? '#dc3545' : r > 0.62 ? '#fd7e14' : '#28a745';

                    L.polyline([routePoints[i], routePoints[i + 1]], {
                        color, weight: 6, opacity: 0.9, lineJoin: 'round'
                    }).addTo(routeGroup);
                }

                trackingMap.fitBounds(routeGroup.getBounds(), { padding: [40, 40] });

                // Ambulance marker
                const ambIcon = L.divIcon({ html: '🚑', className: 'ambulance-marker-icon', iconSize: [30, 30], iconAnchor: [15, 15] });
                ambulanceMarker = L.marker(routePoints[0], { icon: ambIcon }).addTo(trackingMap);
                ambulanceMarker.bindPopup('🚑 Ambulance En Route').openPopup();

                let currentDistance = totalDist;

                const updateUI = () => {
                    document.getElementById('track-dist-val').textContent = (currentDistance / 1000).toFixed(1) + ' km';
                    document.getElementById('track-eta-val').textContent = Math.max(1, Math.ceil(currentDistance / 500)) + ' Min';
                };
                updateUI();

                // Animate ambulance along the route
                let segIdx = 0;
                let segProgress = 0;
                const SPEED = 0.018;

                function animateAmbulance() {
                    if (segIdx >= routePoints.length - 1) {
                        document.getElementById('track-eta-val').textContent = '✅ Arrived';
                        document.getElementById('track-dist-val').textContent = '0.0 km';
                        if (ambulanceMarker) ambulanceMarker.bindPopup('🏥 Arrived at Hospital').openPopup();
                        showToast('Ambulance Arrived', 'Patient has reached the emergency bay.', 'success');
                        return;
                    }

                    segProgress += SPEED;
                    if (segProgress >= 1) {
                        segProgress = 0;
                        segIdx++;
                        if (segIdx >= routePoints.length - 1) {
                            animationTimer = requestAnimationFrame(animateAmbulance);
                            return;
                        }
                    }

                    const start = routePoints[segIdx];
                    const end = routePoints[segIdx + 1];
                    const lat = start[0] + (end[0] - start[0]) * segProgress;
                    const lng = start[1] + (end[1] - start[1]) * segProgress;

                    if (ambulanceMarker) ambulanceMarker.setLatLng([lat, lng]);

                    const segDist = L.latLng(start).distanceTo(L.latLng(end));
                    currentDistance = Math.max(0, currentDistance - segDist * SPEED);

                    if (Math.random() > 0.88) updateUI();

                    animationTimer = requestAnimationFrame(animateAmbulance);
                }

                animationTimer = requestAnimationFrame(animateAmbulance);

            } catch (innerErr) {
                console.error('Tracking map render error:', innerErr);
                showToast('Map Error', 'Could not render tracking map. Please try again.', 'error');
                closeTrackingModal();
            }
        }, 350);

    } catch (outerErr) {
        console.error('Tracking modal open error:', outerErr);
        showToast('Error', 'Failed to open tracker. Please try again.', 'error');
    }
};


