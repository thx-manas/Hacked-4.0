const translations = {
    en: {
        // Navbar
        "nav.title": "Smart Hospital",
        "nav.subtitle": "QUEUE SYSTEM",
        "nav.registration": "Registration",
        "nav.dashboard": "Dashboard",

        // Banner
        "banner.slide1.title": "Smart<br>Triage System",
        "banner.slide1.text": "Our intelligent system analyzes symptoms and automatically assigns the appropriate care priority to ensure everyone gets the help they need.",
        "banner.slide2.title": "Patient<br>Welfare First",
        "banner.slide2.text": "We prioritize patient wellbeing with immediate emergency protocols, ensuring you get the highest standard of care instantly.",
        "banner.slide3.title": "Accurate<br>Routing &amp; Transport",
        "banner.slide3.text": "Receive real-time directions to the nearest hospital and the best transport method based on live traffic and current severity.",

        // Registration Form
        "form.title": "New Patient Registration",
        "form.subtitle": "Enter patient details. Priority will be automatically assessed based on symptoms.",
        "form.name": "Full Name",
        "form.age": "Age",
        "form.phone": "Phone Number",
        "form.location": "Location / Address",
        "form.location.btn": "Use Current Location",
        "form.symptoms": "Symptoms Description",
        "form.photo": "Upload Photo (Optional)",
        "form.report": "Upload Report (Optional)",
        "form.submit": "Register Patient",

        // Dashboard Stats
        "stats.total": "Total in Queue",
        "stats.emergency": "Emergency",
        "stats.high": "High Priority",
        "stats.manual": "Manual Review",

        // Dashboard Queue
        "queue.title": "Patient Queue",
        "queue.btn.call": "⏵ Call Next Patient",
        "queue.filter.all": "All",
        "queue.filter.emergency": "Emergency",
        "queue.filter.high": "High",
        "queue.filter.medium": "Medium",
        "queue.filter.low": "Low",
        "queue.filter.manual": "Manual Review",

        "table.patient": "Patient",
        "table.location": "Location & Transport",
        "table.priority": "Priority & Reasoning",
        "table.confidence": "Confidence",
        "table.evidence": "Evidence",
        "table.actions": "Actions",

        "queue.empty": "The queue is currently empty.",

        "sos.btn": "SOS",
        "sos.confirm": "Trigger SOS Accident Response? An ambulance will be dispatched to your location.",
        
        "track.btn": "Track",
        "track.title": "Live Ambulance Tracker",
        "track.eta": "ETA",
        "track.distance": "Distance",
        "track.hospital": "Destination"
    },
    hi: {
        // Navbar
        "nav.title": "स्मार्ट अस्पताल",
        "nav.subtitle": "कतार प्रणाली",
        "nav.registration": "पंजीकरण",
        "nav.dashboard": "डैशबोर्ड",

        // Banner
        "banner.slide1.title": "स्मार्ट<br>ट्रायज सिस्टम",
        "banner.slide1.text": "हमारी बुद्धिमान प्रणाली लक्षणों का विश्लेषण करती है और स्वचालित रूप से उचित देखभाल प्राथमिकता प्रदान करती है ताकि यह सुनिश्चित हो सके कि सभी को आवश्यक सहायता मिले।",
        "banner.slide2.title": "मरीज<br>कल्याण प्रथम",
        "banner.slide2.text": "हम तत्काल आपातकालीन प्रोटोकॉल के साथ मरीज की भलाई को प्राथमिकता देते हैं, यह सुनिश्चित करते हुए कि आपको तुरंत उच्चतम स्तर की देखभाल मिले।",
        "banner.slide3.title": "सटीक<br>मार्ग और परिवहन",
        "banner.slide3.text": "लाइव ट्रैफ़िक और वर्तमान गंभीरता के आधार पर निकटतम अस्पताल और सर्वोत्तम परिवहन पद्धति के लिए वास्तविक समय के दिशा-निर्देश प्राप्त करें।",

        // Registration Form
        "form.title": "नया मरीज पंजीकरण",
        "form.subtitle": "मरीज का विवरण दर्ज करें। लक्षणों के आधार पर प्राथमिकता का स्वचालित रूप से मूल्यांकन किया जाएगा।",
        "form.name": "पूरा नाम",
        "form.age": "आयु",
        "form.phone": "फ़ोन नंबर",
        "form.location": "स्थान / पता",
        "form.location.btn": "वर्तमान स्थान का उपयोग करें",
        "form.symptoms": "लक्षणों का विवरण",
        "form.photo": "फोटो अपलोड करें (वैकल्पिक)",
        "form.report": "रिपोर्ट अपलोड करें (वैकल्पिक)",
        "form.submit": "मरीज को पंजीकृत करें",

        // Dashboard Stats
        "stats.total": "कतार में कुल",
        "stats.emergency": "आपातकालीन",
        "stats.high": "उच्च प्राथमिकता",
        "stats.manual": "मैनुअल समीक्षा",

        // Dashboard Queue
        "queue.title": "मरीज कतार",
        "queue.btn.call": "⏵ अगले मरीज को बुलाएं",
        "queue.filter.all": "सभी",
        "queue.filter.emergency": "आपातकालीन",
        "queue.filter.high": "उच्च",
        "queue.filter.medium": "मध्यम",
        "queue.filter.low": "निम्न",
        "queue.filter.manual": "मैनुअल समीक्षा",

        "table.patient": "मरीज",
        "table.location": "स्थान और परिवहन",
        "table.priority": "प्राथमिकता और कारण",
        "table.confidence": "आत्मविश्वास",
        "table.evidence": "प्रमाण",
        "table.actions": "क्रियाएँ",

        "queue.empty": "कतार वर्तमान में खाली है।",

        "sos.btn": "एसओएस",
        "sos.confirm": "क्या आप एसओएस दुर्घटना प्रतिक्रिया सक्रिय करना चाहते हैं? आपके स्थान पर एक एम्बुलेंस भेजी जाएगी।",

        "track.btn": "ट्रैक करें",
        "track.title": "लाइव एम्बुलेंस ट्रैकिंग",
        "track.eta": "आगमन का समय",
        "track.distance": "दूरी",
        "track.hospital": "गंतव्य"
    },
    te: {
        // Telugu
        "nav.title": "స్మార్ట్ హాస్పిటల్",
        "nav.subtitle": "క్యూ సిస్టమ్",
        "nav.registration": "నమోదు",
        "nav.dashboard": "డాష్‌బోర్డ్",

        "banner.slide1.title": "స్మార్ట్<br>ట్రయాజ్ సిస్టమ్",
        "banner.slide1.text": "మా స్మార్ట్ సిస్టమ్ లక్షణాలను విశ్లేషిస్తుంది మరియు ప్రతి ఒక్కరికీ అవసరమైన సహాయం అందేలా ఆటోమేటిక్‌గా తగిన సంరక్షణ ప్రాధాన్యతను ఇస్తుంది.",
        "banner.slide2.title": "రోగి<br>సంక్షేమం ముఖ్యం",
        "banner.slide2.text": "మేము అత్యవసర ప్రోటోకాల్‌ల ద్వారా రోగి శ్రేయస్సుకు ప్రాధాన్యత ఇస్తాము, తక్షణం అత్యున్నత స్థాయి సేవలు అందేలా చూస్తాము.",
        "banner.slide3.title": "ఖచ్చితమైన<br>మార్గం & రవాణా",
        "banner.slide3.text": "లైవ్ ట్రాఫిక్ డిమాండ్ల ఆధారంగా సమీప ఆసుపత్రి మరియు ఉత్తమ రవాణా పద్ధతి గురించి ఖచ్చితమైన దారి నిర్దేశాన్ని పొందండి.",

        "form.title": "కొత్త రోగి నమోదు",
        "form.subtitle": "రోగి వివరాలను నమోదు చేయండి. లక్షణాల ఆధారంగా ప్రాధాన్యత స్వయంచాలకంగా అంచనా వేయబడుతుంది.",
        "form.name": "పూర్తి పేరు",
        "form.age": "వయస్సు",
        "form.phone": "ఫోన్ నంబర్",
        "form.location": "స్థానం / చిరునామా",
        "form.location.btn": "ప్రస్తుత స్థానాన్ని ఉపయోగించండి",
        "form.symptoms": "లక్షణాల వివరణ",
        "form.photo": "ఫోటోను అప్‌లోడ్ చేయండి (ఐచ్ఛికం)",
        "form.report": "రక్తం లేదా రిపోర్ట్‌ను అప్‌లోడ్ చేయండి (ఐచ్ఛికం)",
        "form.submit": "రోగిని నమోదు చేయండి",

        "stats.total": "క్యూలో మొత్తం",
        "stats.emergency": "అత్యవసర",
        "stats.high": "అధిక ప్రాధాన్యత",
        "stats.manual": "మాన్యువల్ సమీక్ష",

        "queue.title": "రోగి క్యూ",
        "queue.btn.call": "⏵ తదుపరి రోగిని పిలవండి",
        "queue.filter.all": "అన్ని",
        "queue.filter.emergency": "అత్యవసర",
        "queue.filter.high": "అధిక",
        "queue.filter.medium": "మధ్యస్థ",
        "queue.filter.low": "తక్కువ",
        "queue.filter.manual": "మాన్యువల్ సమీక్ష",

        "table.patient": "రోగి",
        "table.location": "స్థానం & రవాణా",
        "table.priority": "ప్రాధాన్యత & కారణం",
        "table.confidence": "విశ్వాసం",
        "table.evidence": "సాక్ష్యం",
        "table.actions": "చర్యలు",

        "queue.empty": "ప్రస్తుతం క్యూ పట్టిక ఖాళీగా ఉంది.",

        "sos.btn": "SOS",
        "sos.confirm": "SOS ప్రమాద ప్రతిస్పందనను ప్రారంభించాలా? మీ స్థానానికి అంబులెన్స్ పంపబడుతుంది.",

        "track.btn": "ట్రాక్ చేయండి",
        "track.title": "లైవ్ అంబులెన్స్ ట్రాకర్",
        "track.eta": "ETA",
        "track.distance": "దూరం",
        "track.hospital": "గమ్యం"
    },
    ta: {
        // Tamil
        "nav.title": "ஸ்மார்ட் மருத்துவமனை",
        "nav.subtitle": "வரிசை அமைப்பு",
        "nav.registration": "பதிவு",
        "nav.dashboard": "டாஷ்போர்டு",

        "banner.slide1.title": "ஸ்மார்ட்<br>ட்ரேஜ் சிஸ்டம்",
        "banner.slide1.text": "அனைவருக்கும் தேவையான உதவிகள் கிடைப்பதை உறுதிசெய்ய எங்களுடைய ஸ்மார்ட் சிஸ்டம் அறிகுறிகளை ஆராய்ந்து தானாக முன்னுரிமை அளிக்கிறது.",
        "banner.slide2.title": "நோயாளி<br>நலன் முதலில்",
        "banner.slide2.text": "அவசரகால நெறிமுறைகளுடன் நோயாளி நலனுக்கு முன்னுரிமை அளிக்கிறோம், உடனடியாக உயர்ந்த மருத்துவ சேவையை உறுதி செய்கிறோம்.",
        "banner.slide3.title": "சரியான<br>பாதை & போக்குவரத்து",
        "banner.slide3.text": "போக்குவரத்து நெரிசல் மற்றும் தீவிரத்தின் அடிப்படையில் அருகிலுள்ள மருத்துவமனை மற்றும் சிறந்த போக்குவரத்தை அறிய சரியான வழியைக் காண்க.",

        "form.title": "புதிய நோயாளி பதிவு",
        "form.subtitle": "நோயாளி விவரங்களை உள்ளிடவும். முன்னுரிமை தானாகவே மதிப்பிடப்படும்.",
        "form.name": "முழு பெயர்",
        "form.age": "வயது",
        "form.phone": "தொலைபேசி எண்",
        "form.location": "இடம் / முகவரி",
        "form.location.btn": "தற்போதைய இடத்தைப் பயன்படுத்தவும்",
        "form.symptoms": "அறிகுறிகளின் விளக்கம்",
        "form.photo": "புகைப்படத்தை பதிவேற்று (விருப்பம்)",
        "form.report": "அறிக்கையை பதிவேற்று (விருப்பம்)",
        "form.submit": "நோயாளியை பதிவு செய்",

        "stats.total": "வரிசையில் உள்ளவர்கள்",
        "stats.emergency": "அவசரம்",
        "stats.high": "அதிக முன்னுரிமை",
        "stats.manual": "கையேடு மதிப்பாய்வு",

        "queue.title": "நோயாளி வரிசை",
        "queue.btn.call": "⏵ அடுத்த நோயாளியை அழைக்கவும்",
        "queue.filter.all": "அனைத்தும்",
        "queue.filter.emergency": "அவசரம்",
        "queue.filter.high": "உயர்",
        "queue.filter.medium": "நடுத்தரம்",
        "queue.filter.low": "குறைந்த",
        "queue.filter.manual": "கையேடு மதிப்பாய்வு",

        "table.patient": "நோயாளி",
        "table.location": "இடம் & போக்குவரத்து",
        "table.priority": "முன்னுரிமை & காரணம்",
        "table.confidence": "நம்பிக்கை",
        "table.evidence": "சான்று",
        "table.actions": "செயல்கள்",

        "queue.empty": "தற்போது வரிசை காலியாக உள்ளது.",

        "sos.btn": "SOS",
        "sos.confirm": "SOS விபத்து பதிலளிப்பைத் தூண்டவா? உங்கள் இருப்பிடத்திற்கு ஆம்புலன்ஸ் அனுப்பப்படும்.",

        "track.btn": "கண்காணி",
        "track.title": "நேரடி ஆம்புலன்ஸ் கண்காணிப்பு",
        "track.eta": "ETA",
        "track.distance": "தூரம்",
        "track.hospital": "சேருமிடம்"
    }
};
